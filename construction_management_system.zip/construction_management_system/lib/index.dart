// Export pages
export '/onboarding/onboarding_widget.dart' show OnboardingWidget;
export '/login_page/login_page_widget.dart' show LoginPageWidget;
export '/sign_up_page/sign_up_page_widget.dart' show SignUpPageWidget;
export '/login_success/login_success_widget.dart' show LoginSuccessWidget;
export '/signup_success/signup_success_widget.dart' show SignupSuccessWidget;
export '/profile_update/profile_update_widget.dart' show ProfileUpdateWidget;
export '/forgot_password/forgot_password_widget.dart' show ForgotPasswordWidget;
export '/dash_board/dash_board_widget.dart' show DashBoardWidget;
export '/dashboard_widget/dashboard_widget_widget.dart'
    show DashboardWidgetWidget;
export '/employee_page/employee_page_widget.dart' show EmployeePageWidget;
export '/payment_page/payment_page_widget.dart' show PaymentPageWidget;
export '/project_grid_page/project_grid_page_widget.dart'
    show ProjectGridPageWidget;
export '/transaction_success/transaction_success_widget.dart'
    show TransactionSuccessWidget;
export '/transaction_failed/transaction_failed_widget.dart'
    show TransactionFailedWidget;
export '/calender_page/calender_page_widget.dart' show CalenderPageWidget;
export '/project_detail/project_detail_widget.dart' show ProjectDetailWidget;
export '/appsetting/appsetting_widget.dart' show AppsettingWidget;
export '/customer_page/customer_page_widget.dart' show CustomerPageWidget;
