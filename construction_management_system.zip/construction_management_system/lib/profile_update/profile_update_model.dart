import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'profile_update_widget.dart' show ProfileUpdateWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfileUpdateModel extends FlutterFlowModel<ProfileUpdateWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for username widget.
  FocusNode? usernameFocusNode;
  TextEditingController? usernameController;
  String? Function(BuildContext, String?)? usernameControllerValidator;
  // State field(s) for useremail widget.
  FocusNode? useremailFocusNode;
  TextEditingController? useremailController;
  String? Function(BuildContext, String?)? useremailControllerValidator;
  // State field(s) for userphone widget.
  FocusNode? userphoneFocusNode;
  TextEditingController? userphoneController;
  String? Function(BuildContext, String?)? userphoneControllerValidator;
  // State field(s) for address widget.
  FocusNode? addressFocusNode;
  TextEditingController? addressController;
  String? Function(BuildContext, String?)? addressControllerValidator;
  // State field(s) for Gender widget.
  FocusNode? genderFocusNode;
  TextEditingController? genderController;
  String? Function(BuildContext, String?)? genderControllerValidator;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    unfocusNode.dispose();
    usernameFocusNode?.dispose();
    usernameController?.dispose();

    useremailFocusNode?.dispose();
    useremailController?.dispose();

    userphoneFocusNode?.dispose();
    userphoneController?.dispose();

    addressFocusNode?.dispose();
    addressController?.dispose();

    genderFocusNode?.dispose();
    genderController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
