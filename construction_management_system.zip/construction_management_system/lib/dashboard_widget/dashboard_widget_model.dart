import '/components/dashboard_bottom_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dashboard_widget_widget.dart' show DashboardWidgetWidget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DashboardWidgetModel extends FlutterFlowModel<DashboardWidgetWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for Dashboard_Bottom component.
  late DashboardBottomModel dashboardBottomModel;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    dashboardBottomModel = createModel(context, () => DashboardBottomModel());
  }

  void dispose() {
    unfocusNode.dispose();
    dashboardBottomModel.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
