import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_calendar.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'create_task_widget.dart' show CreateTaskWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreateTaskModel extends FlutterFlowModel<CreateTaskWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for Tasktitle widget.
  FocusNode? tasktitleFocusNode;
  TextEditingController? tasktitleController;
  String? Function(BuildContext, String?)? tasktitleControllerValidator;
  // State field(s) for task_details widget.
  FocusNode? taskDetailsFocusNode;
  TextEditingController? taskDetailsController;
  String? Function(BuildContext, String?)? taskDetailsControllerValidator;
  // State field(s) for milestone widget.
  String? milestoneValue;
  FormFieldController<String>? milestoneValueController;
  // State field(s) for assignee widget.
  String? assigneeValue;
  FormFieldController<String>? assigneeValueController;
  // State field(s) for due_date widget.
  DateTimeRange? dueDateSelectedDay;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    dueDateSelectedDay = DateTimeRange(
      start: DateTime.now().startOfDay,
      end: DateTime.now().endOfDay,
    );
  }

  void dispose() {
    tasktitleFocusNode?.dispose();
    tasktitleController?.dispose();

    taskDetailsFocusNode?.dispose();
    taskDetailsController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
