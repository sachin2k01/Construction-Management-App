import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'customer_add_widget.dart' show CustomerAddWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CustomerAddModel extends FlutterFlowModel<CustomerAddWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for cust_Name widget.
  FocusNode? custNameFocusNode;
  TextEditingController? custNameController;
  String? Function(BuildContext, String?)? custNameControllerValidator;
  // State field(s) for cust_phone widget.
  FocusNode? custPhoneFocusNode;
  TextEditingController? custPhoneController;
  String? Function(BuildContext, String?)? custPhoneControllerValidator;
  // State field(s) for cust_location widget.
  FocusNode? custLocationFocusNode;
  TextEditingController? custLocationController;
  String? Function(BuildContext, String?)? custLocationControllerValidator;
  // State field(s) for cust_project widget.
  FocusNode? custProjectFocusNode;
  TextEditingController? custProjectController;
  String? Function(BuildContext, String?)? custProjectControllerValidator;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    custNameFocusNode?.dispose();
    custNameController?.dispose();

    custPhoneFocusNode?.dispose();
    custPhoneController?.dispose();

    custLocationFocusNode?.dispose();
    custLocationController?.dispose();

    custProjectFocusNode?.dispose();
    custProjectController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
