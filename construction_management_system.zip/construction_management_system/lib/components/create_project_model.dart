import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_calendar.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'create_project_widget.dart' show CreateProjectWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreateProjectModel extends FlutterFlowModel<CreateProjectWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for projectName widget.
  FocusNode? projectNameFocusNode;
  TextEditingController? projectNameController;
  String? Function(BuildContext, String?)? projectNameControllerValidator;
  // State field(s) for projectId widget.
  FocusNode? projectIdFocusNode;
  TextEditingController? projectIdController;
  String? Function(BuildContext, String?)? projectIdControllerValidator;
  // State field(s) for projectlocation widget.
  FocusNode? projectlocationFocusNode;
  TextEditingController? projectlocationController;
  String? Function(BuildContext, String?)? projectlocationControllerValidator;
  // State field(s) for project_goal widget.
  FocusNode? projectGoalFocusNode;
  TextEditingController? projectGoalController;
  String? Function(BuildContext, String?)? projectGoalControllerValidator;
  // State field(s) for due_date widget.
  DateTimeRange? dueDateSelectedDay;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  ProjectsRecord? newProject;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    dueDateSelectedDay = DateTimeRange(
      start: DateTime.now().startOfDay,
      end: DateTime.now().endOfDay,
    );
  }

  void dispose() {
    projectNameFocusNode?.dispose();
    projectNameController?.dispose();

    projectIdFocusNode?.dispose();
    projectIdController?.dispose();

    projectlocationFocusNode?.dispose();
    projectlocationController?.dispose();

    projectGoalFocusNode?.dispose();
    projectGoalController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
