import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'signup_bottom_widget.dart' show SignupBottomWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SignupBottomModel extends FlutterFlowModel<SignupBottomWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for RegisterEmail widget.
  FocusNode? registerEmailFocusNode;
  TextEditingController? registerEmailController;
  String? Function(BuildContext, String?)? registerEmailControllerValidator;
  // State field(s) for RegisterPassword widget.
  FocusNode? registerPasswordFocusNode;
  TextEditingController? registerPasswordController;
  late bool registerPasswordVisibility;
  String? Function(BuildContext, String?)? registerPasswordControllerValidator;
  // State field(s) for ConfirmPassword widget.
  FocusNode? confirmPasswordFocusNode;
  TextEditingController? confirmPasswordController;
  late bool confirmPasswordVisibility;
  String? Function(BuildContext, String?)? confirmPasswordControllerValidator;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    registerPasswordVisibility = false;
    confirmPasswordVisibility = false;
  }

  void dispose() {
    registerEmailFocusNode?.dispose();
    registerEmailController?.dispose();

    registerPasswordFocusNode?.dispose();
    registerPasswordController?.dispose();

    confirmPasswordFocusNode?.dispose();
    confirmPasswordController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
