import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'employee_add_widget.dart' show EmployeeAddWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EmployeeAddModel extends FlutterFlowModel<EmployeeAddWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for emp_Name widget.
  FocusNode? empNameFocusNode;
  TextEditingController? empNameController;
  String? Function(BuildContext, String?)? empNameControllerValidator;
  // State field(s) for emp_id widget.
  FocusNode? empIdFocusNode;
  TextEditingController? empIdController;
  String? Function(BuildContext, String?)? empIdControllerValidator;
  // State field(s) for emp_phone widget.
  FocusNode? empPhoneFocusNode;
  TextEditingController? empPhoneController;
  String? Function(BuildContext, String?)? empPhoneControllerValidator;
  // State field(s) for emp_location widget.
  FocusNode? empLocationFocusNode;
  TextEditingController? empLocationController;
  String? Function(BuildContext, String?)? empLocationControllerValidator;
  // State field(s) for emp_work widget.
  FocusNode? empWorkFocusNode;
  TextEditingController? empWorkController;
  String? Function(BuildContext, String?)? empWorkControllerValidator;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    empNameFocusNode?.dispose();
    empNameController?.dispose();

    empIdFocusNode?.dispose();
    empIdController?.dispose();

    empPhoneFocusNode?.dispose();
    empPhoneController?.dispose();

    empLocationFocusNode?.dispose();
    empLocationController?.dispose();

    empWorkFocusNode?.dispose();
    empWorkController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
