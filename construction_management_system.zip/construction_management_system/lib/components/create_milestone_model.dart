import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_calendar.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'create_milestone_widget.dart' show CreateMilestoneWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreateMilestoneModel extends FlutterFlowModel<CreateMilestoneWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for MilestoneName widget.
  FocusNode? milestoneNameFocusNode;
  TextEditingController? milestoneNameController;
  String? Function(BuildContext, String?)? milestoneNameControllerValidator;
  // State field(s) for milestone_goal widget.
  FocusNode? milestoneGoalFocusNode;
  TextEditingController? milestoneGoalController;
  String? Function(BuildContext, String?)? milestoneGoalControllerValidator;
  // State field(s) for due_date widget.
  DateTimeRange? dueDateSelectedDay;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    dueDateSelectedDay = DateTimeRange(
      start: DateTime.now().startOfDay,
      end: DateTime.now().endOfDay,
    );
  }

  void dispose() {
    milestoneNameFocusNode?.dispose();
    milestoneNameController?.dispose();

    milestoneGoalFocusNode?.dispose();
    milestoneGoalController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
