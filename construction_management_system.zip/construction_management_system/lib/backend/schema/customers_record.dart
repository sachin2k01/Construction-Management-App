import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CustomersRecord extends FirestoreRecord {
  CustomersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "customer_name" field.
  String? _customerName;
  String get customerName => _customerName ?? '';
  bool hasCustomerName() => _customerName != null;

  // "contact_no" field.
  String? _contactNo;
  String get contactNo => _contactNo ?? '';
  bool hasContactNo() => _contactNo != null;

  // "customer_location" field.
  String? _customerLocation;
  String get customerLocation => _customerLocation ?? '';
  bool hasCustomerLocation() => _customerLocation != null;

  // "profile_pic" field.
  String? _profilePic;
  String get profilePic => _profilePic ?? '';
  bool hasProfilePic() => _profilePic != null;

  // "project_ref" field.
  DocumentReference? _projectRef;
  DocumentReference? get projectRef => _projectRef;
  bool hasProjectRef() => _projectRef != null;

  // "Due_date" field.
  DateTime? _dueDate;
  DateTime? get dueDate => _dueDate;
  bool hasDueDate() => _dueDate != null;

  // "project" field.
  String? _project;
  String get project => _project ?? '';
  bool hasProject() => _project != null;

  void _initializeFields() {
    _customerName = snapshotData['customer_name'] as String?;
    _contactNo = snapshotData['contact_no'] as String?;
    _customerLocation = snapshotData['customer_location'] as String?;
    _profilePic = snapshotData['profile_pic'] as String?;
    _projectRef = snapshotData['project_ref'] as DocumentReference?;
    _dueDate = snapshotData['Due_date'] as DateTime?;
    _project = snapshotData['project'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('customers');

  static Stream<CustomersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CustomersRecord.fromSnapshot(s));

  static Future<CustomersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CustomersRecord.fromSnapshot(s));

  static CustomersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CustomersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CustomersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CustomersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CustomersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CustomersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCustomersRecordData({
  String? customerName,
  String? contactNo,
  String? customerLocation,
  String? profilePic,
  DocumentReference? projectRef,
  DateTime? dueDate,
  String? project,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'customer_name': customerName,
      'contact_no': contactNo,
      'customer_location': customerLocation,
      'profile_pic': profilePic,
      'project_ref': projectRef,
      'Due_date': dueDate,
      'project': project,
    }.withoutNulls,
  );

  return firestoreData;
}

class CustomersRecordDocumentEquality implements Equality<CustomersRecord> {
  const CustomersRecordDocumentEquality();

  @override
  bool equals(CustomersRecord? e1, CustomersRecord? e2) {
    return e1?.customerName == e2?.customerName &&
        e1?.contactNo == e2?.contactNo &&
        e1?.customerLocation == e2?.customerLocation &&
        e1?.profilePic == e2?.profilePic &&
        e1?.projectRef == e2?.projectRef &&
        e1?.dueDate == e2?.dueDate &&
        e1?.project == e2?.project;
  }

  @override
  int hash(CustomersRecord? e) => const ListEquality().hash([
        e?.customerName,
        e?.contactNo,
        e?.customerLocation,
        e?.profilePic,
        e?.projectRef,
        e?.dueDate,
        e?.project
      ]);

  @override
  bool isValidKey(Object? o) => o is CustomersRecord;
}
