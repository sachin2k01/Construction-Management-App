import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EmployeesRecord extends FirestoreRecord {
  EmployeesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "emp_name" field.
  String? _empName;
  String get empName => _empName ?? '';
  bool hasEmpName() => _empName != null;

  // "emp_id" field.
  int? _empId;
  int get empId => _empId ?? 0;
  bool hasEmpId() => _empId != null;

  // "work" field.
  String? _work;
  String get work => _work ?? '';
  bool hasWork() => _work != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "emp_phone" field.
  String? _empPhone;
  String get empPhone => _empPhone ?? '';
  bool hasEmpPhone() => _empPhone != null;

  // "emp_photo" field.
  String? _empPhoto;
  String get empPhoto => _empPhoto ?? '';
  bool hasEmpPhoto() => _empPhoto != null;

  // "project_ref" field.
  DocumentReference? _projectRef;
  DocumentReference? get projectRef => _projectRef;
  bool hasProjectRef() => _projectRef != null;

  void _initializeFields() {
    _empName = snapshotData['emp_name'] as String?;
    _empId = castToType<int>(snapshotData['emp_id']);
    _work = snapshotData['work'] as String?;
    _location = snapshotData['location'] as String?;
    _empPhone = snapshotData['emp_phone'] as String?;
    _empPhoto = snapshotData['emp_photo'] as String?;
    _projectRef = snapshotData['project_ref'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('employees');

  static Stream<EmployeesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EmployeesRecord.fromSnapshot(s));

  static Future<EmployeesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EmployeesRecord.fromSnapshot(s));

  static EmployeesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      EmployeesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EmployeesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EmployeesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EmployeesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EmployeesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEmployeesRecordData({
  String? empName,
  int? empId,
  String? work,
  String? location,
  String? empPhone,
  String? empPhoto,
  DocumentReference? projectRef,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'emp_name': empName,
      'emp_id': empId,
      'work': work,
      'location': location,
      'emp_phone': empPhone,
      'emp_photo': empPhoto,
      'project_ref': projectRef,
    }.withoutNulls,
  );

  return firestoreData;
}

class EmployeesRecordDocumentEquality implements Equality<EmployeesRecord> {
  const EmployeesRecordDocumentEquality();

  @override
  bool equals(EmployeesRecord? e1, EmployeesRecord? e2) {
    return e1?.empName == e2?.empName &&
        e1?.empId == e2?.empId &&
        e1?.work == e2?.work &&
        e1?.location == e2?.location &&
        e1?.empPhone == e2?.empPhone &&
        e1?.empPhoto == e2?.empPhoto &&
        e1?.projectRef == e2?.projectRef;
  }

  @override
  int hash(EmployeesRecord? e) => const ListEquality().hash([
        e?.empName,
        e?.empId,
        e?.work,
        e?.location,
        e?.empPhone,
        e?.empPhoto,
        e?.projectRef
      ]);

  @override
  bool isValidKey(Object? o) => o is EmployeesRecord;
}
