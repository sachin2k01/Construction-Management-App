import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyA7QMKMmh9tpIhxkIDPxYzb2-5e7I4KObU",
            authDomain: "construction-ms-718ed.firebaseapp.com",
            projectId: "construction-ms-718ed",
            storageBucket: "construction-ms-718ed.appspot.com",
            messagingSenderId: "260449377719",
            appId: "1:260449377719:web:c6b94f57d8df014116dc32",
            measurementId: "G-BE8J7DPWV7"));
  } else {
    await Firebase.initializeApp();
  }
}
